(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/richsilv_owl-carousel/packages/richsilv_owl-carousel.js  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['richsilv:owl-carousel'] = {};

})();

//# sourceMappingURL=richsilv_owl-carousel.js.map
