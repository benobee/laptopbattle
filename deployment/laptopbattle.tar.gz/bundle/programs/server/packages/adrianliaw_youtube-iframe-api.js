(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/adrianliaw_youtube-iframe-api/packages/adrianliaw_youtub //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['adrianliaw:youtube-iframe-api'] = {};

})();

//# sourceMappingURL=adrianliaw_youtube-iframe-api.js.map
