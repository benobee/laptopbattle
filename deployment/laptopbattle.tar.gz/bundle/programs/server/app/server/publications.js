(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish("videos", function () {                                 // 1
                                                                       //
		return Videos.find();                                                // 3
});                                                                    //
                                                                       //
Meteor.publish("comments", function () {                               // 7
                                                                       //
		return Comments.find();                                              // 9
});                                                                    //
                                                                       //
Meteor.publish("levels", function () {                                 // 13
                                                                       //
		return Levels.find();                                                // 15
});                                                                    //
                                                                       //
Meteor.publish("users", function () {                                  // 19
                                                                       //
		return Meteor.users.find({}, {                                       // 21
				fields: {                                                          // 23
						username: 1,                                                     // 24
						votes: 1,                                                        // 25
						pointCount: 1,                                                   // 26
						admin: 1,                                                        // 27
						age: 1,                                                          // 28
						location: 1,                                                     // 29
						player: 1,                                                       // 30
						profile: 1,                                                      // 31
						emails: 1                                                        // 32
				}                                                                  //
		}, {                                                                 //
				sort: {                                                            // 36
						pointCount: -1                                                   // 38
				}                                                                  //
		});                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
