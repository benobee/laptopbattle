(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/houstonAdmin.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Houston.add_collection(Meteor.users);                                  // 1
Houston.add_collection(Houston._admins);                               // 2
                                                                       //
Houston._admins.insert({ 'user_id': 'LQi2g4sNt4kyDk5jh' });            // 4
Houston._admins.insert({ 'user_id': 'mYuid8yBpdvPJhuL6' });            // 5
Houston._admins.insert({ 'user_id': '37SdJXu2f9HamyGfe' });            // 6
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=houstonAdmin.js.map
