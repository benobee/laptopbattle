(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/security.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Accounts.users.allow({                                                 // 1
  update: function () {                                                // 2
                                                                       //
    return true;                                                       // 4
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.users.deny({                                                    // 9
  update: function () {                                                // 10
                                                                       //
    return true;                                                       // 12
  }                                                                    //
});                                                                    //
                                                                       //
Accounts.users.allow({                                                 // 17
  remove: function () {                                                // 18
                                                                       //
    if (Meteor.user().profile.admin) {                                 // 20
                                                                       //
      return true;                                                     // 22
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=security.js.map
